// Yahoo Finance provider (unofficial, ~15 min delayed). Uses the yahoo-finance2 package, which handles cookies and crumbs.
import YahooFinance from 'yahoo-finance2';

const yf = new YahooFinance({ suppressNotices: ['yahooSurvey'] });
const DAY = 86_400_000;
const opts = { validateResult: false };

const utcDay = (d) => Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
const iso = (ms) => new Date(ms).toISOString().slice(0, 10);
const n = (x) => (typeof x === 'number' && Number.isFinite(x) ? x : 0);

/** Converts one Yahoo expiry block into normalized contracts. Exported for tests. */
export function normalize(sym, block, today) {
  const expMs = utcDay(new Date(block.expirationDate));
  const dte = Math.round((expMs - today) / DAY);
  if (dte < 0) return [];
  const exp = iso(expMs);
  const out = [];
  for (const [list, type] of [[block.calls || [], 'C'], [block.puts || [], 'P']]) {
    for (const o of list) {
      if (!o || !(o.strike > 0)) continue;
      out.push({ sym, type, strike: o.strike, exp, dte, vol: n(o.volume), oi: n(o.openInterest), bid: n(o.bid), ask: n(o.ask), last: n(o.lastPrice) });
    }
  }
  return out;
}

export async function fetchSymbol(sym, { maxDte, maxExpiries }) {
  const today = utcDay(new Date());
  const first = await yf.options(sym, {}, opts);
  const spot = first?.quote?.regularMarketPrice;
  if (!(spot > 0)) throw new Error('no_price');
  const dates = (first.expirationDates || [])
    .map((d) => utcDay(new Date(d)))
    .filter((ms) => ms >= today && (ms - today) / DAY <= maxDte)
    .sort((a, b) => a - b)
    .slice(0, maxExpiries);
  const rows = [];
  const have = new Set();
  for (const block of first.options || []) {
    const ms = utcDay(new Date(block.expirationDate));
    if (dates.includes(ms)) { rows.push(...normalize(sym, block, today)); have.add(ms); }
  }
  for (const ms of dates) {
    if (have.has(ms)) continue;
    const res = await yf.options(sym, { date: new Date(ms) }, opts);
    for (const block of res.options || []) rows.push(...normalize(sym, block, today));
    await new Promise((r) => setTimeout(r, 150));
  }
  return { spot, rows };
}
