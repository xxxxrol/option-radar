// Demo provider for local development and tests. Generates plausible but fake contracts. Never use for decisions.
const DEMO = {
  NVDA: [202, .48, 9], AAPL: [228, .26, 8], MSFT: [430, .24, 6], AMZN: [210, .32, 6], GOOGL: [185, .30, 5], META: [590, .38, 5],
  TSLA: [255, .62, 9], AMD: [160, .52, 6], AVGO: [175, .45, 4], NFLX: [780, .36, 3], ORCL: [175, .34, 3], CRM: [300, .32, 3],
  PLTR: [75, .70, 6], COIN: [250, .78, 4], MU: [105, .55, 4], INTC: [24, .50, 5], ARM: [140, .60, 3], UBER: [78, .38, 3],
  JPM: [235, .22, 3], BAC: [45, .26, 4], V: [305, .20, 2], LLY: [800, .34, 2], COST: [940, .24, 2], WMT: [90, .20, 3],
  BA: [155, .40, 3], SPY: [590, .14, 10], QQQ: [500, .18, 9],
};
const DTES = [2, 9, 16, 30, 58];
const ticks = new Map();

function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6D2B79F5) >>> 0; let t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
const stepFor = (p) => (p < 25 ? .5 : p < 100 ? 1 : p < 250 ? 2.5 : p < 600 ? 5 : p < 1500 ? 10 : 25);

export async function fetchSymbol(sym, { maxDte, maxExpiries }) {
  const tick = (ticks.get(sym) || 0); ticks.set(sym, tick + 1);
  const day = new Date().toISOString().slice(0, 10), t0 = Date.parse(day + 'T00:00:00Z');
  const c = DEMO[sym] || [40 + hash(sym) % 300, .4, 3];
  const spot = Math.round(c[0] * (1 + (rng(hash(sym + day + 's' + tick))() - .5) * .01) * 100) / 100;
  const r0 = rng(hash(sym + day)), rt = rng(hash(sym + day + 't' + tick));
  const step = stepFor(spot), atm = Math.round(spot / step) * step, hot = {};
  for (let h = 0; h < 7; h++) hot[Math.floor(r0() * 3) + '|' + (Math.floor(r0() * 13) - 3) + '|' + (r0() < .65 ? 'C' : 'P')] = 1;
  const rows = [];
  DTES.filter((d) => d <= maxDte).slice(0, maxExpiries).forEach((dte, ei) => {
    const T = dte / 365, sd = c[1] * Math.sqrt(T), exp = new Date(t0 + dte * 86400000).toISOString().slice(0, 10);
    for (let i = -12; i <= 12; i++) {
      const K = Math.round((atm + i * step) * 100) / 100; if (K <= 0) continue;
      for (const type of ['C', 'P']) {
        const m = K / spot - 1;
        const oi = Math.max(5, Math.round(c[2] * 1000 * Math.exp(-Math.pow(m / (.07 + sd * .3), 2)) * (.6 + r0() * .9) * (type === 'C' ? 1.15 : 1) * (dte <= 9 ? 1.1 : .9)));
        let ratio = .04 + r0() * .3; const isHot = !!hot[ei + '|' + i + '|' + type];
        if (isHot) ratio *= 2 + r0() * 5;
        const vol = Math.round(oi * ratio * (1 + .02 * tick) * (isHot ? 1 + .07 * tick : 1) * (.92 + rt() * .16));
        const intr = type === 'C' ? Math.max(0, spot - K) : Math.max(0, K - spot);
        const mark = Math.max(.02, intr + spot * sd * .4 * Math.exp(-Math.pow(m / (sd * 1.3 + .001), 2)));
        const sp = Math.min(.6, .012 + r0() * .035 + Math.abs(m) * .25);
        rows.push({ sym, type, strike: K, exp, dte, vol, oi, bid: mark * (1 - sp / 2), ask: mark * (1 + sp / 2), last: mark });
      }
    }
  });
  return { spot, rows };
}
