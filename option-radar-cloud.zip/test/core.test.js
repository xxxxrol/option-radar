import test from 'node:test';
import assert from 'node:assert/strict';
import { finish } from '../lib/score.js';
import { isMarketOpen } from '../lib/market.js';
import { normalize } from '../providers/yahoo.js';

const base = { sym: 'NVDA', type: 'C', strike: 207, exp: '2026-11-13', dte: 8, vol: 12000, oi: 3000, bid: 2.9, ask: 3.0, last: 2.95 };

test('hot near-the-money contract scores high', () => {
  const r = finish(base, 202);
  assert.equal(r.mny, 'OTM');
  assert.ok(r.voloi >= 3.9 && r.voloi <= 4.1);
  assert.ok(r.score >= 80, `score ${r.score}`);
  assert.equal(r.key, 'NVDA|2026-11-13|207|C');
});

test('quiet far contract scores low', () => {
  const r = finish({ ...base, strike: 260, vol: 150, oi: 9000, bid: 0.05, ask: 0.2, dte: 40 }, 202);
  assert.ok(r.score < 30, `score ${r.score}`);
});

test('score stays within 0..100 and survives zero open interest', () => {
  const r = finish({ ...base, oi: 0, bid: 0, ask: 0, last: 1 }, 202);
  assert.ok(r.score >= 0 && r.score <= 100);
});

test('market hours in New York time', () => {
  assert.equal(isMarketOpen(new Date('2026-11-04T15:00:00Z')), true);  // Wed 10:00 ET
  assert.equal(isMarketOpen(new Date('2026-11-04T23:30:00Z')), false); // Wed 18:30 ET
  assert.equal(isMarketOpen(new Date('2026-11-07T15:00:00Z')), false); // Saturday
});

test('yahoo block is normalized and past expiries are dropped', () => {
  const today = Date.UTC(2026, 10, 5);
  const block = { expirationDate: new Date('2026-11-13T00:00:00Z'), calls: [{ strike: 200, volume: 10, openInterest: 5, bid: 1, ask: 1.2, lastPrice: 1.1 }, { strike: 0 }], puts: [{ strike: 190, openInterest: 7 }] };
  const rows = normalize('AAPL', block, today);
  assert.equal(rows.length, 2);
  assert.deepEqual(rows[0], { sym: 'AAPL', type: 'C', strike: 200, exp: '2026-11-13', dte: 8, vol: 10, oi: 5, bid: 1, ask: 1.2, last: 1.1 });
  assert.equal(rows[1].vol, 0);
  assert.deepEqual(normalize('AAPL', { ...block, expirationDate: new Date('2026-11-01T00:00:00Z') }, today), []);
});
