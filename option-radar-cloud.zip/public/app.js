(function () {
  'use strict';
  var DEFAULT_TICKERS = 'NVDA,AAPL,MSFT,AMZN,GOOGL,META,TSLA,AMD,AVGO,NFLX,ORCL,CRM,PLTR,COIN,MU,INTC,ARM,UBER,JPM,BAC,V,LLY,COST,WMT,BA,SPY,QQQ';
  var DTES = [2, 9, 16, 30, 58];
  var $ = function (id) { return document.getElementById(id); };
  var st = { meta: null, rows: [], spots: {}, sel: null, sort: { key: 'score', dir: -1 }, limit: 40, seen: {}, alerts: [], first: true, timer: null, busy: false, last: null, audio: null, err: '' };

  // ---------- helpers ----------
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(seed) { var a = seed >>> 0; return function () { a = (a + 0x6D2B79F5) >>> 0; var t = a; t = Math.imul(t ^ t >>> 15, t | 1); t ^= t + Math.imul(t ^ t >>> 7, t | 61); return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function clamp(x) { return Math.max(0, Math.min(1, x)); }
  function fmt(n, d) { return Number(n).toLocaleString('en-US', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }); }
  function money(n) { if (n >= 1e9) return '$' + (n / 1e9).toFixed(2) + 'B'; if (n >= 1e6) return '$' + (n / 1e6).toFixed(2) + 'M'; if (n >= 1e3) return '$' + (n / 1e3).toFixed(0) + 'K'; return '$' + n.toFixed(0); }
  function num(v, extra) { return '<span class="num">' + v + '</span>'; }
  function dateStr(d) { return d.toISOString().slice(0, 10); }
  function todayUTC() { var n = new Date(); return Date.UTC(n.getUTCFullYear(), n.getUTCMonth(), n.getUTCDate()); }
  function saveSet() { try { localStorage.setItem('optradar.v1', JSON.stringify(readSettings())); } catch (e) {} }
  function loadSet() { try { var j = JSON.parse(localStorage.getItem('optradar.v1') || 'null'); if (j) { for (var k in j) { var el = $(k); if (!el) continue; if (el.type === 'checkbox') el.checked = !!j[k]; else el.value = j[k]; } } } catch (e) {} }
  var SETTING_IDS = ['tickers', 'type', 'maxDte', 'minVol', 'minOI', 'minScore', 'maxDist', 'every', 'auto', 'aOn', 'aScore', 'aRatio', 'aSound'];
  function readSettings() { var o = {}; SETTING_IDS.forEach(function (id) { var el = $(id); o[id] = el.type === 'checkbox' ? el.checked : el.value; }); return o; }
  function symbols() {
    var seen = {}, out = [];
    $('tickers').value.toUpperCase().split(/[\s,;،]+/).forEach(function (s) { s = s.replace(/[^A-Z0-9.\-]/g, ''); if (s && !seen[s] && out.length < 60) { seen[s] = 1; out.push(s); } });
    return out;
  }
  function cfg() {
    return {
      type: $('type').value, maxDte: +$('maxDte').value, minVol: +$('minVol').value || 0, minOI: +$('minOI').value || 0,
      minScore: +$('minScore').value || 0, maxDist: +$('maxDist').value || 100, aOn: $('aOn').checked, aScore: +$('aScore').value || 0, aRatio: +$('aRatio').value || 0
    };
  }

  // ---------- scan ----------
  function clock(ms) { return new Date(ms).toLocaleTimeString('en-GB'); }
  function setBanner() {
    var b = $('banner'), m = st.meta;
    if (st.err) { b.className = 'banner err'; b.innerHTML = '<b>تنبيه</b><span>' + st.err + '</span>'; return; }
    if (!m) { b.className = 'banner demo'; b.innerHTML = '<b>جارٍ التحميل</b><span>أتصل بالخادم...</span>'; return; }
    var bad = Object.keys(m.errors || {}), parts = [];
    if (m.provider === 'demo') {
      b.className = 'banner demo';
      b.innerHTML = '<b>وضع التطوير</b><span>الخادم يعمل بالمزود التجريبي: الأرقام مولّدة ولا تمثل السوق.</span>';
      return;
    }
    parts.push('متأخرة نحو ' + m.delayedMin + ' دقيقة');
    parts.push('السوق ' + (m.marketOpen ? 'مفتوح' : 'مغلق، والأحجام تعود لآخر جلسة'));
    if (m.asOf) parts.push('آخر جلب من ياهو ' + clock(m.asOf));
    if (m.pending && m.pending.length) parts.push('جارٍ جلب: ' + m.pending.join('، '));
    if (bad.length) parts.push('تعذر جلب: ' + bad.slice(0, 6).join('، '));
    b.className = 'banner live';
    b.innerHTML = '<b>بيانات ياهو</b><span>' + parts.join(' · ') + '.</span>';
  }
  function passes(r, c) {
    return (c.type === 'all' || r.type === c.type) && r.dte <= c.maxDte && r.vol >= c.minVol && r.oi >= c.minOI && r.score >= c.minScore && Math.abs(r.dist) <= c.maxDist && r.mid > 0;
  }
  function filtered() { var c = cfg(); return st.rows.filter(function (r) { return passes(r, c); }); }

  async function runScan() {
    if (st.busy) return;
    st.busy = true; $('scan').disabled = true;
    var ctrl = new AbortController(), to = setTimeout(function () { ctrl.abort(); }, 25000);
    try {
      var q = '/api/scan?symbols=' + encodeURIComponent(symbols().join(',')) + '&minVol=' + Math.max(0, Math.min(+$('minVol').value || 0, 1e9));
      var res = await fetch(q, { cache: 'no-store', signal: ctrl.signal });
      if (res.status === 401) throw { m: 'مطلوب تسجيل الدخول. حدّث الصفحة وأدخل كلمة المرور.' };
      if (res.status === 429) throw { m: 'طلبات كثيرة. انتظر دقيقة ثم حاول.' };
      if (!res.ok) throw { m: 'خطأ من الخادم (' + res.status + ').' };
      var d = await res.json();
      st.meta = d; st.rows = d.rows || []; st.spots = d.spots || {}; st.last = d.asOf ? new Date(d.asOf) : null; st.err = '';
      evalAlerts();
    } catch (e) {
      st.err = e && e.m ? e.m : (e && e.name === 'AbortError' ? 'انتهت مهلة الاتصال بالخادم.' : 'تعذر الاتصال بالخادم.');
    }
    clearTimeout(to);
    st.busy = false; $('scan').disabled = false; $('scan').textContent = 'فحص الآن';
    setBanner(); render(); schedule();
  }
  function schedule() {
    if (st.timer) clearInterval(st.timer);
    st.timer = null;
    if (!$('auto').checked) return;
    var s = +$('every').value || 30;
    st.timer = setInterval(function () { if (!document.hidden) runScan(); }, s * 1000);
  }

  // ---------- alerts ----------
  function beep() {
    if (!$('aSound').checked) return;
    try {
      st.audio = st.audio || new (window.AudioContext || window.webkitAudioContext)();
      var o = st.audio.createOscillator(), g = st.audio.createGain();
      o.type = 'sine'; o.frequency.value = 880; g.gain.value = .06; o.connect(g); g.connect(st.audio.destination);
      o.start(); o.stop(st.audio.currentTime + .18);
    } catch (e) {}
  }
  function toast(html) {
    var t = document.createElement('div'); t.className = 'toast'; t.innerHTML = html; $('toasts').appendChild(t);
    setTimeout(function () { t.remove(); }, 9000);
    while ($('toasts').children.length > 4) $('toasts').firstChild.remove();
  }
  function label(r) { return r.sym + ' ' + fmt(r.strike, r.strike % 1 ? 2 : 0) + ' ' + (r.type === 'C' ? 'Call' : 'Put'); }
  function evalAlerts() {
    var c = cfg(), hits = [];
    st.rows.forEach(function (r) {
      if (passes(r, c) && r.score >= c.aScore && r.voloi >= c.aRatio && !st.seen[r.key]) { st.seen[r.key] = 1; hits.push(r); }
    });
    if (st.first) { if (st.rows.length) st.first = false; return; }
    if (!c.aOn || !hits.length) return;
    hits.sort(function (a, b) { return b.score - a.score; });
    hits.forEach(function (r) { st.alerts.unshift({ t: new Date(), r: r }); });
    st.alerts = st.alerts.slice(0, 60);
    hits.slice(0, 3).forEach(function (r) {
      toast('<b>زخم على ' + r.sym + '</b><br><span class="num">' + label(r) + '</span> · استحقاق <span class="num">' + r.dte + '</span> يوم · حجم/OI <span class="num">' + r.voloi.toFixed(1) + '</span> · زخم <span class="num">' + r.score + '</span>');
    });
    if (hits.length > 3) toast('و ' + (hits.length - 3) + ' تنبيهات أخرى في السجل');
    beep();
  }

  // ---------- render ----------
  var COLS = [
    ['sym', 'الرمز', 'stick'], ['type', 'النوع', ''], ['strike', 'السترايك', 'n'], ['spot', 'السعر', 'n'], ['dist', 'البعد', 'n'],
    ['dte', 'الاستحقاق', 'n'], ['vol', 'الحجم', 'n'], ['oi', 'OI', 'n'], ['voloi', 'حجم/OI', 'n'], ['value', 'قيمة التداول', 'n'],
    ['spread', 'السبريد', 'n'], ['score', 'الزخم', '']
  ];
  function head() {
    $('thead').innerHTML = COLS.map(function (c) {
      var s = st.sort.key === c[0] ? (st.sort.dir < 0 ? 'descending' : 'ascending') : 'none';
      return '<th class="' + c[2] + '" data-k="' + c[0] + '" aria-sort="' + s + '" scope="col">' + c[1] + '</th>';
    }).join('');
  }
  function sorted(list) {
    var k = st.sort.key, d = st.sort.dir;
    return list.slice().sort(function (a, b) {
      var x = a[k], y = b[k];
      if (typeof x === 'string') return d * (x < y ? -1 : x > y ? 1 : 0) || b.score - a.score;
      return d * (x - y) || b.score - a.score;
    });
  }
  function renderTable(list) {
    var top = sorted(list), shown = top.slice(0, st.limit);
    $('tblNote').textContent = list.length ? 'يعرض ' + shown.length + ' من ' + list.length + ' عقد' : '';
    if (!list.length) {
      var wait = !st.rows.length && st.meta && st.meta.pending && st.meta.pending.length;
      $('tbody').innerHTML = '<tr><td colspan="' + COLS.length + '" class="empty">' + (wait ? 'الخادم يجمع البيانات لأول مرة. تتحدث الصفحة تلقائياً خلال دقيقة.' : 'لا توجد عقود تطابق الفلاتر. خفّف الحد الأدنى للحجم أو الزخم.') + '</td></tr>';
    } else {
      $('tbody').innerHTML = shown.map(function (r) {
        return '<tr data-s="' + r.sym + '" class="' + (r.sym === st.sel ? 'sel' : '') + '">'
          + '<td class="stick sym-cell">' + r.sym + '</td>'
          + '<td><span class="tag ' + r.type + '">' + (r.type === 'C' ? 'Call' : 'Put') + '</span> <span class="pill">' + r.mny + '</span></td>'
          + '<td class="n">' + num(fmt(r.strike, r.strike % 1 ? 2 : 0)) + '</td>'
          + '<td class="n">' + num(fmt(r.spot, 2)) + '</td>'
          + '<td class="n">' + num((r.dist > 0 ? '+' : '') + r.dist.toFixed(1) + '%') + '</td>'
          + '<td class="n">' + num(r.dte + 'd') + '</td>'
          + '<td class="n">' + num(fmt(r.vol)) + '</td>'
          + '<td class="n">' + num(fmt(r.oi)) + '</td>'
          + '<td class="n">' + num(r.voloi.toFixed(2)) + '</td>'
          + '<td class="n">' + num(money(r.value)) + '</td>'
          + '<td class="n">' + num((r.spread * 100).toFixed(1) + '%') + '</td>'
          + '<td><span class="score"><span class="bar"><i style="width:' + r.score + '%"></i></span><b>' + r.score + '</b></span></td></tr>';
      }).join('');
    }
    $('more').hidden = list.length <= st.limit;
  }
  function renderStats(list) {
    if (!list.length) { $('stats').innerHTML = '<div class="stat"><span class="k">العقود المطابقة</span><span class="v">' + num('0') + '</span></div>'; return; }
    var topS = list.reduce(function (a, b) { return b.score > a.score ? b : a; });
    var topV = list.reduce(function (a, b) { return b.vol > a.vol ? b : a; });
    var tot = 0, calls = 0; list.forEach(function (r) { tot += r.value; if (r.type === 'C') calls += r.value; });
    var share = tot ? Math.round(calls / tot * 100) : 50;
    $('stats').innerHTML =
      '<div class="stat"><span class="k">العقود المطابقة</span><span class="v">' + num(fmt(list.length)) + '</span><span class="s">من ' + num(fmt(st.rows.length)) + ' عقد تم فحصه</span></div>'
      + '<div class="stat"><span class="k">أعلى زخم</span><span class="v">' + num(topS.score) + '</span><span class="s">' + num(label(topS)) + '</span></div>'
      + '<div class="stat"><span class="k">أعلى حجم</span><span class="v">' + num(fmt(topV.vol)) + '</span><span class="s">' + num(label(topV)) + '</span></div>'
      + '<div class="stat"><span class="k">إجمالي البريميوم</span><span class="v">' + num(money(tot)) + '</span><span class="s">Call ' + num(share + '%') + ' · Put ' + num((100 - share) + '%') + '</span><div class="tilt" aria-hidden="true"><i style="width:' + share + '%"></i></div></div>'
      + '<div class="stat"><span class="k">آخر تحديث</span><span class="v">' + num(st.last ? st.last.toLocaleTimeString('en-GB') : '-') + '</span><span class="s">' + (st.meta && st.meta.provider === 'demo' ? 'بيانات تجريبية' : 'ياهو، متأخرة 15 دقيقة') + '</span></div>';
  }
  function renderIdeas(list) {
    var by = {}, picks = [];
    list.slice().sort(function (a, b) { return b.score - a.score; }).forEach(function (r) { if (!by[r.sym]) { by[r.sym] = 1; picks.push(r); } });
    picks = picks.slice(0, 5);
    $('ideas').innerHTML = picks.length ? picks.map(function (r) {
      return '<button type="button" class="idea" data-s="' + r.sym + '"><div class="hd"><span class="sym">' + r.sym + '</span><span class="score"><b>' + r.score + '</b></span></div>'
        + '<div class="ct"><span class="tag ' + r.type + '">' + (r.type === 'C' ? 'Call' : 'Put') + '</span> ' + num(fmt(r.strike, r.strike % 1 ? 2 : 0)) + ' <span class="muted">· ' + num(r.dte + 'd') + ' · ' + r.mny + '</span></div>'
        + '<div class="mt"><span>حجم ' + num(fmt(r.vol)) + '</span><span>حجم/OI ' + num(r.voloi.toFixed(1)) + '</span><span>' + num(money(r.value)) + '</span></div></button>';
    }).join('') : '<p class="muted">لا توجد أفكار مطابقة للفلاتر الحالية.</p>';
  }
  function renderDetail(list) {
    var sym = st.sel;
    if (!sym || !st.spots[sym]) { var t = list.slice().sort(function (a, b) { return b.score - a.score; })[0]; sym = t ? t.sym : (st.rows[0] && st.rows[0].sym); st.sel = sym; }
    if (!sym) { $('detail').innerHTML = '<p class="muted">لا توجد بيانات بعد.</p>'; $('detSym').textContent = ''; return; }
    var c = cfg(), spot = st.spots[sym];
    var all = st.rows.filter(function (r) { return r.sym === sym && r.dte <= c.maxDte; });
    var byK = {}, ks = [], callV = 0, putV = 0, prem = 0;
    all.forEach(function (r) {
      var o = byK[r.strike]; if (!o) { o = byK[r.strike] = { C: 0, P: 0, hot: false }; ks.push(r.strike); }
      o[r.type] += r.vol; if (r.type === 'C') callV += r.vol; else putV += r.vol; prem += r.value;
      if (r.score >= c.aScore && r.voloi >= c.aRatio) o.hot = true;
    });
    ks.sort(function (a, b) { return a - b; });
    $('detSym').innerHTML = '<span class="num">' + sym + ' · ' + fmt(spot, 2) + '</span>';
    if (!ks.length) { $('detail').innerHTML = '<p class="muted">لا توجد عقود ضمن نطاق الاستحقاق المختار.</p>'; return; }
    var W = 600, H = 270, L = 8, R = 8, T = 26, B = 30, iw = W - L - R, ih = H - T - B, mid = T + ih / 2, n = ks.length, bw = iw / n;
    var maxV = 1; ks.forEach(function (k) { maxV = Math.max(maxV, byK[k].C, byK[k].P); });
    var hh = ih / 2 - 6, svg = '';
    svg += '<line x1="' + L + '" x2="' + (W - R) + '" y1="' + mid + '" y2="' + mid + '" stroke="var(--line)" stroke-width="1"/>';
    ks.forEach(function (k, i) {
      var o = byK[k], x = L + i * bw + bw * .15, w = bw * .7, hc = o.C / maxV * hh, hp = o.P / maxV * hh, st1 = o.hot ? ' stroke="var(--heat)" stroke-width="1.6"' : '';
      svg += '<rect x="' + x.toFixed(1) + '" y="' + (mid - hc).toFixed(1) + '" width="' + w.toFixed(1) + '" height="' + hc.toFixed(1) + '" fill="var(--call)" fill-opacity="' + (o.hot ? 1 : .6) + '"' + st1 + '><title>' + k + ' Call ' + fmt(o.C) + '</title></rect>';
      svg += '<rect x="' + x.toFixed(1) + '" y="' + mid + '" width="' + w.toFixed(1) + '" height="' + hp.toFixed(1) + '" fill="var(--put)" fill-opacity="' + (o.hot ? 1 : .6) + '"' + st1 + '><title>' + k + ' Put ' + fmt(o.P) + '</title></rect>';
    });
    var every = Math.ceil(n / 9);
    ks.forEach(function (k, i) { if (i % every === 0) svg += '<text x="' + (L + i * bw + bw / 2).toFixed(1) + '" y="' + (H - 10) + '" text-anchor="middle">' + fmt(k, k % 1 ? 1 : 0) + '</text>'; });
    var sx = L + bw / 2;
    if (spot <= ks[0]) sx = L + bw / 2; else if (spot >= ks[n - 1]) sx = L + (n - 1) * bw + bw / 2;
    else for (var j = 0; j < n - 1; j++) if (spot >= ks[j] && spot < ks[j + 1]) { sx = L + j * bw + bw / 2 + (spot - ks[j]) / (ks[j + 1] - ks[j]) * bw; break; }
    svg += '<line x1="' + sx.toFixed(1) + '" x2="' + sx.toFixed(1) + '" y1="' + (T - 4) + '" y2="' + (H - B + 2) + '" stroke="var(--ink)" stroke-width="1.2" stroke-dasharray="4 3"/>';
    svg += '<text class="spot" x="' + Math.max(40, Math.min(W - 40, sx)).toFixed(1) + '" y="12" text-anchor="middle">' + fmt(spot, 2) + '</text>';
    svg += '<text x="' + L + '" y="' + (T + 8) + '">' + fmt(maxV) + '</text><text x="' + L + '" y="' + (H - B - 2) + '">' + fmt(maxV) + '</text>';
    var mine = all.filter(function (r) { return passes(r, c); }).sort(function (a, b) { return b.score - a.score; }).slice(0, 4);
    $('detail').innerHTML =
      '<div class="kv"><div><div class="k">حجم Call</div><div class="v">' + num(fmt(callV)) + '</div></div><div><div class="k">حجم Put</div><div class="v">' + num(fmt(putV)) + '</div></div><div><div class="k">Put/Call</div><div class="v">' + num((putV / Math.max(1, callV)).toFixed(2)) + '</div></div></div>'
      + '<div class="legend"><span><i style="background:var(--call)"></i>Call (أعلى الخط)</span><span><i style="background:var(--put)"></i>Put (أسفل الخط)</span><span><i style="background:none;border:2px solid var(--heat)"></i>سترايك ينطبق عليه شرط التنبيه</span></div>'
      + '<svg class="ladder" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="حجم التداول لكل سترايك على ' + sym + '، وخط متقطع عند السعر الحالي">' + svg + '</svg>'
      + '<ul class="mini">' + (mine.length ? mine.map(function (r) {
        return '<li><span class="tag ' + r.type + '">' + (r.type === 'C' ? 'Call' : 'Put') + '</span>' + num(fmt(r.strike, r.strike % 1 ? 2 : 0)) + '<span class="muted">' + num(r.dte + 'd') + '</span><span class="muted">حجم/OI ' + num(r.voloi.toFixed(1)) + '</span><span class="sp score"><b>' + r.score + '</b></span></li>';
      }).join('') : '<li class="muted">لا عقود تطابق الفلاتر لهذا السهم.</li>') + '</ul>';
  }
  function renderAlerts() {
    $('alog').innerHTML = st.alerts.length ? st.alerts.map(function (a) {
      var r = a.r;
      return '<li><span class="t">' + a.t.toLocaleTimeString('en-GB') + '</span><span><b>' + r.sym + '</b> ' + num(fmt(r.strike, r.strike % 1 ? 2 : 0) + ' ' + (r.type === 'C' ? 'Call' : 'Put')) + ' · <span class="muted">' + num(r.dte + 'd') + '</span></span><span class="muted">زخم ' + num(r.score) + ' · حجم/OI ' + num(r.voloi.toFixed(1)) + ' · حجم ' + num(fmt(r.vol)) + '</span></li>';
    }).join('') : '<li class="muted">لا تنبيهات بعد. يظهر هنا أي عقد جديد يتجاوز شروطك أثناء التحديثات.</li>';
  }
  function render() {
    var list = filtered();
    head(); renderStats(list); renderIdeas(list); renderTable(list); renderDetail(list); renderAlerts();
  }

  // ---------- CSV ----------
  function csv() {
    var h = ['symbol', 'type', 'strike', 'spot', 'dist_pct', 'expiry', 'dte', 'volume', 'open_interest', 'vol_oi', 'premium_usd', 'spread_pct', 'score'];
    var lines = [h.join(',')];
    sorted(filtered()).forEach(function (r) { lines.push([r.sym, r.type === 'C' ? 'call' : 'put', r.strike, r.spot.toFixed(2), r.dist.toFixed(2), r.exp, r.dte, r.vol, r.oi, r.voloi.toFixed(2), Math.round(r.value), (r.spread * 100).toFixed(1), r.score].join(',')); });
    return lines.join('\n');
  }
  function copyCsv() {
    var text = csv(), btn = $('copyCsv');
    function ok() { btn.textContent = 'تم النسخ'; setTimeout(function () { btn.textContent = 'نسخ CSV'; }, 1600); }
    function fallback() {
      var ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); ok(); } catch (e) { btn.textContent = 'تعذر النسخ'; } ta.remove();
    }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(ok, fallback); else fallback();
  }

  // ---------- events ----------
  loadSet();
  if (!$('tickers').value) $('tickers').value = DEFAULT_TICKERS;
  $('scan').addEventListener('click', function () { saveSet(); runScan(); });
  $('copyCsv').addEventListener('click', copyCsv);
  $('thead').addEventListener('click', function (e) {
    var th = e.target.closest('th'); if (!th) return; var k = th.getAttribute('data-k');
    if (st.sort.key === k) st.sort.dir *= -1; else st.sort = { key: k, dir: (k === 'sym' || k === 'type' || k === 'dte' || k === 'spread' || k === 'dist') ? 1 : -1 };
    render();
  });
  function pick(e) { var el = e.target.closest('[data-s]'); if (!el) return; st.sel = el.getAttribute('data-s'); render(); }
  $('tbody').addEventListener('click', pick); $('ideas').addEventListener('click', pick);
  $('more').addEventListener('click', function () { st.limit += 40; render(); });
  ['type', 'maxDte', 'minVol', 'minOI', 'minScore', 'maxDist', 'aOn', 'aScore', 'aRatio', 'aSound'].forEach(function (id) {
    $(id).addEventListener('change', function () { saveSet(); st.limit = 40; render(); });
  });
  $('aSound').addEventListener('change', function () { if ($('aSound').checked) beep(); });
  $('auto').addEventListener('change', function () { saveSet(); schedule(); });
  $('every').addEventListener('change', function () { saveSet(); schedule(); });
  $('tickers').addEventListener('keydown', function (e) { if (e.key === 'Enter') { saveSet(); runScan(); } });

  setBanner(); runScan();
})();
